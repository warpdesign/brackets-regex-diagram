brackets-regex-diagram
======================

A regular expression railroad diagram view for regexp under the cursor. This was written so that I can get familiar with Brackets development.

This extension is heavily based on:

* [regex-railroad-diagram package](https://github.com/klorenz/atom-regex-railroad-diagrams) Atom extension by [@klorenz](https://github.com/klorenz/)
* [railroad-diagrams](http://github.com/tabatkins/railroad-diagrams) Rairoad Diagrams by [Tab Atkins Jr.](http://twitter.com/tabatkins)

![brackets-regex-diagram](img/screenshot.png)