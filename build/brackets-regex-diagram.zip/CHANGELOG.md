# Changelog

## 0.0.3
* FIXED: do not open diagram panel with '/' string
* CLEANED-UP: removed some frequent debug messages

## 0.0.2
* IMPROVED: better styling of the panel, should now make it obvious it's resizable
* IMPROVED: added a title with the RegExp being analyzed

## 0.0.1
* Initial Release
