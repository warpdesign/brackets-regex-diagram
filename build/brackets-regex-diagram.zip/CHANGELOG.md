# Changelog

## 0.0.2
* IMPROVED: better styling of the panel, should now make it obvious it's resizable
* IMPROVED: added a title with the RegExp being analyzed

## 0.0.1
* Initial Release
